public class Equals1
{
public static void main( String [] args )
{
int x=5,y=5,z=6;
System.out.println("x is " + x +" y is " + y +" z is " + z); 
System . out . println ("x==y is " + (x==y));
System . out . println ("x==z is " + (x==z));
String r = new String ("Help") ;
String s = new String ("Help") ;
String t = new String ("HELP") ;
System . out . println ("\nr is " + r +" s is "+ s +" t is " + t);
System . out . println ("r==s is " + (r==s));
System . out . println ("r==t is " + (r==t));
}
}
