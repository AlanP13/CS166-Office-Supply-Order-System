public class Equals2
{
public String r;
Equals()
{
	r="Help";
}
Equals(String q)
{
	r=q;
}
public boolean equals(Equals2 q)
{
	if(this.r ==q.r)
	{
		return true;
	}
	else
	{
		return false;
	}
}
}
