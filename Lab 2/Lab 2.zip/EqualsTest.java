public class EqualsTest 
{
	public static void main( String [] args )
	{
		Equals r= new Equals("Help");
		Equals s= new Equals("Help");
		Equals t= new Equals("HELP");
		System.out.println("r.equals(s) is: "+r.equals(s));
		System.out.println("r.equals(t) ignoring case is: "+r.r.equalsIgnoreCase( t.r ));
	}
}
