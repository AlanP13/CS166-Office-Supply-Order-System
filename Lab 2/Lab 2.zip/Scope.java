public class Scope {
private static int one = 1 ;
private int two ;
public int three ;
public static final int FOUR = 4 ;
public Scope ( int w, int x )
{
int q=5;
one++;
this.two = w;
this.three = x ;
}
public void change ( int x )
{
int q=10;
int y = one + x ;
two = one * y ;
three = three*FOUR;
}
public String toString ( )
{
return ( " one = " + one + " two = " + two + " three = " + three ) ;
}
}