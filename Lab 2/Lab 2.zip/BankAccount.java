package com.labs.lab2;

public class BankAccount {
	
	private double bal;
	private String name;
	private String accountType;
	private double overdrawLimit; 
	
	public BankAccount(double bal1, String name1, String accountType1, double overdrawLimit1)
	{
		if(bal1 >= (overdrawLimit1*-1.0))
		{
			this.bal = bal1;
		}
		
		this.name = name1;
		this.accountType = accountType1;
		this.overdrawLimit = overdrawLimit1;
		
	}
	public double getBalance() {
		return this.bal;
	}
	public double withDraw(double amount)
	{
		if (this.accountType.contentEquals("Savings"))
		{
			if ( (this.bal - (amount + 3)) >= overdrawLimit)
			{
				this.bal = this.bal - (amount + 3);
				return amount;
			}
			else 
			{
				return 0.0;
			}
		}
		else 
		{
			if ( (this.bal - amount) >= this.overdrawLimit)
			{
				this.bal = this.bal - amount;
				return amount;
			}
			else 
			{
				return 0.0;
			}
		}
	}
	
	public void deposit(double amount)
	{
		this.bal = this.bal + amount;
	}
	
	public boolean transfer(BankAccount A, double amount)
	{
		if((this.bal - amount) >= this.overdrawLimit)
		{
			this.bal = this.bal - amount;
			A.deposit(amount);
			return true;
		}
		else
		{
			return false;
		}
	}

	public String toString() 
	{
		return "BankAccount [Balance is:" + bal + ", Owner's name is:" + name + ", Account Type is:" + accountType
				+ ", Overdraw Limit is:" + overdrawLimit + "]";
	}
	
}
