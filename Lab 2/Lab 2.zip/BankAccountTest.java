package com.labs.lab1;

import com.labs.lab2.BankAccount;

public class BankAccountTest {

	public static void main(String[] args) {
		BankAccount Alice = new BankAccount(100.0, "Alice", "Savings", 50.0);
		BankAccount Bob = new BankAccount(350.0, "Bob", "Checkings", 30.0);
		
		Bob.withDraw(200.0);
		Bob.withDraw(1000.0);
                Alice.deposit(50.0);
		Bob.transfer(Alice, 75);
		
		System.out.println(Bob.toString());
		System.out.println(Alice.toString());
		
	}

}
