package com.labs.lab2;

public class InterestCalculator {
	
	private static double Interest = 0.0;
	
	public static double applyInterest(BankAccount a, int years, double interestRate)
	{
		Interest = a.getBalance() * (1 + (interestRate/100));
		
		return Interest;
	}
	
	public static void main(String[] args) {
		BankAccount Alice = new BankAccount(110.0, "Alice", "Savings", 30.0);
		System.out.println("Balance after Interest: " + applyInterest(Alice, 8, 0.05));
	}
}
