import java.util.ArrayList;
import java.util.Arrays;
class Student extends Person{
	String courseName;
    int grade;
    int numCourses;
    ArrayList<Course> courses;
    public Student(String name, String address) {
        super(name, address);
    }    public void addCourseGrade(String course, int grade){
        numCourses++;
        if(courses==null){  
            courses = new ArrayList<Course>();
        }
        courses.add(new Course(course,grade));
    }

    public void printGrades(){
        System.out.println("Grades are:");
        for(Course c : courses){  
            System.out.println(c);
        }
    }

    public double getAverageGrade(){
        double sum = 0;
        for(Course c : courses) {
            sum = sum + c.getGrade();
        }
        return sum/numCourses; 
    }
    @Override
    public String toString() {
        return super.toString() +
                ", numCourses=" + numCourses +
                ", courses=" + Arrays.toString(courses.toArray());
    }
}