import java.util.ArrayList;
import java.util.Arrays;
class Teacher extends Person{

    String c1;
    public Teacher(String name, String address) {
        super(name, address);
    }

    public String getCourse1() {
        return c1;
    }

    public void setCourse1(String course1) {
        this.c1 = course1;
    }
    @Override
    public String toString() {
        return super.toString() + ", Course 1='" + c1 ;
    }
}