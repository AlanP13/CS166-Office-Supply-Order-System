class Course {

    String courseName;
    int grade;

    public Course(String courseName, int grade) {
        this.courseName = courseName;
        this.grade = grade;
    }

    public int getGrade() {
        return grade;
    }

    @Override
    public String toString() {
        return "Course Name is:'" + courseName +", Grade=" + grade;
    }
}