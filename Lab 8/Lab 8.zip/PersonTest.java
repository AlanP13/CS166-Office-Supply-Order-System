import java.util.ArrayList;
import java.util.Arrays;
public class PersonTest {
	 public static void main(String[] args) {

	        Student student = new Student("Alan","Chicago"); 
	        System.out.println("Name: "+student.getName()); 
	        System.out.println("Address: "+student.getAddress());

	        student.addCourseGrade("Maths", 94);  
	        student.addCourseGrade("Physics",92);
	        student.addCourseGrade("Computer Science",90);
	        student.printGrades();  
	        System.out.println("Average grade of student: "+student.getAverageGrade());

	        Teacher teacher = new Teacher("Labib","New York");
	        System.out.println(teacher);   

	        teacher.setCourse1("Maths"); 
	        System.out.println("Courses taken by teacher :"+teacher); 
	        System.out.println(teacher.getCourse1());
	        	    }
}
