import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class FileReader1_2 
{_
	public static void main(String[] args)
	{  
	try
	{
	Scanner file = new Scanner ( new File (" data.txt " ));
	int n =0;
	while ( file . hasNext ())
	{
	String s = file . nextLine ();
	if (s . equals (" A" ))
	n ++;
	}
	System . out . println ( " The value of n is r" + n );
	File . close ();
	}
	catch ( IOException ioe )
	{
	ioe . printStackTrace ();
	}
    }
}
/*
The following code doesn't work, its just for reference
Answer:
Output:
The value of n is 3
 */