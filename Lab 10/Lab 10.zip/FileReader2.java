import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class FileReader2 {
	public static void main(String[] args)
	{  
	
	try
	{
	Scanner file = new Scanner ( new File ("C:\\Users\\alanp\\eclipse-workspace\\Lab_10\\data.txt" ));
	String result = "";
	while(file.hasNext())
	{
		result = result + file.nextLine() + " ";
	}
	System.out.println(result);
	}
	catch ( IOException ioe )
	{
	ioe . printStackTrace ();
	}

	}
}
/*
Answer:
while(file.hasNext())
{
	result = result + file.nextLine() + " ";
}
System.out.println(result);
}
*/