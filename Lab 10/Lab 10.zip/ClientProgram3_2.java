import java.util.*;
import java.io.*;
public class ClientProgram3_2
{
   public static void main(String[] args)throws FileNotFoundException
   {
       FileCompare3_2 fc=new FileCompare3_2();
       fc.findDifferences();
   }
}