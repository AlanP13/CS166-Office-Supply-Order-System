import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
public class FileScanner1_1 {
	public static void main(String[] args)
	{  

	try
	{
	Scanner file = new Scanner ( new File( "words.txt"));
	String result = "";
	while ( file.hasNext())

	{
	String s = file.next();
	result += s;
	result+= " And";
	}
	System.out.println ( "Result is "+result);
	File.close();
	}
	catch ( FileNotFoundException fne)
	{
	System.out.println( "Unable to find words.txt");
	}
	catch (IOException Ioe)
	{
	Ioe.printStackTrace();
	}
	}
}
/*
The following code doesn't work, its just for reference
Answer:
If file words.txt is found the 
output is:

CS2 And Java And Illuminated

If file is not found, error 
message is displayed:
Unable to find words.txt
 */