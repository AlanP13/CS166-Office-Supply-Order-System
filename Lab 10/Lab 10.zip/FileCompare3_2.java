import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
class FileCompare3_2
{
   String filebuff1,filebuff2,filename="";
   Scanner in, in1, in2;
   public FileCompare3_2() throws FileNotFoundException
   {      
       in=null;
       in1=null;
       in2=null;
   }
   public void findDifferences() throws FileNotFoundException
   {   
	   in=new Scanner(System.in);
       System.out.print("Enter a file 1 name: ");
       filename=in.nextLine();  
       in1=new Scanner(new File(filename));
       System.out.print("Enter a file 2 name: ");
       filename=in.next();
       in2=new Scanner(new File(filename));
       if(in1==null || in2==null)
       {
           System.err.println("Input file is not found");
       }
       int line=0;
       while(in1.hasNext()&& in2.hasNext())
       {          
           filebuff1=in1.nextLine();
           filebuff2=in2.nextLine();      
           if(filebuff1.compareTo(filebuff2)!=0)
           {
               line++;
               System.out.println("Number"+line+":");
               System.out.println("> "+filebuff1);
               System.out.println("> "+filebuff2);
               System.out.println();
           }
       }
       System.out.println("There are "+(line)+" different lines are found");
       if(in1.hasNext())
       {
           System.out.println("File 1 has more data, file 2 does not");
       }
       else if(in2.hasNext())
       {
           System.out.println("File 2 has more data, file 1 does not");
       }
       in1.close();
       in2.close();   
   }  
}