import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;

public class LineReader3_1
{
public static void main(String[] args)
{  
  
   try{
      
       File file =new File("C:\\Users\\alanp\\eclipse-workspace\\Lab_10\\file1.txt");
      
       if(file.exists()){
          
       FileReader fr = new FileReader(file);
       LineNumberReader lnr = new LineNumberReader(fr);
      
       int linenumber = 0;
      
   while (lnr.readLine() != null){
       linenumber++;
   }
     
   System.out.println("Total number of lines : " + linenumber);
     
   lnr.close();
  
         
       }else{
           System.err.println("File does not exists!");
       }
      
   }catch(IOException e){
       e.printStackTrace();
   }
  
}
}