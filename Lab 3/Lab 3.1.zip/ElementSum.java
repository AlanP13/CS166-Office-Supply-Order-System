
public class ElementSum 
{
	public static void main(String[] args) 
	{
	int sum=0;
	for(int i=0;i<args.length;i++)
{
	sum+=Integer.parseInt(args[i]);
}
	System.out.print("Java Sum");
	for(int j=0;j<args.length;j++)
	{
		System.out.print(" "+args[j]+" ");
	}
	System.out.print("will be: "+sum);
}
}