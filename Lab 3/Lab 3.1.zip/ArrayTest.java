public class ArrayTest {
	public static void differentArray (float[] x)
	{
		x= new float[100];
		x[0]=26.9f;
	}
	public static void differentArray2 (float[] x)
	{
		x[0]=26.9f;
	}
	public static void main(String[] args) 
	{
	float []y=new float[100];
	y[0]=55.8f;
	differentArray(y);
	System.out.println("y[0]="+y[0]);
	differentArray2(y);
	System.out.println("y[0]="+y[0]);
	}
}
