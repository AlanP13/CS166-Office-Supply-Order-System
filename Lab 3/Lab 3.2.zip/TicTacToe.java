public class TicTacToe {
	   int board[] = new int[9];
	   int turn;
	   int moves;
	   public TicTacToe()
	   {
	       for(int i = 0; i <=8; i++)
	       {
	           board[i] = 0;
	       }
	       turn = 1;
	       moves = 0;
	   }
	   public void move(int turn1, int position1)
	   {
		   if(position1 < 0 || position1 > 9) 
		   {
			   System.out.println("Invalid move");
	       }
		   else
		   {
	           board[position1] = turn1;
	           moves++;
	           if(turn == 1) turn = 2;
	           else turn = 1;
	       }
	   }
	   public void win()
	   {
	       if(won())
	       {
	           int p = 1;
	           if(turn == 1) p = 2;
	           System.out.println("Player " + p + " won");
	       }
	       else if(tie())
	    	   {
	    	   System.out.println("Tie game");
	    	   }
	   }
	   public boolean tie()
	   {
	       if(won() == false && moves == 9) 
	    	   {
	    	   return true;
	    	   }
	       else
	    	   {
	    	   return false;
	    	   }
	   }
	   
	  public boolean won()
	  {
	       if(board[0] == board[1] && board[1] == board[2] && board[2] != 0)
	       {
	           return true;
	       }
	       else if(board[3] == board[4] && board[4] == board[5] && board[5] != 0)
	       {
	           return true;
	       }
	       else if(board[6] == board[7] && board[7] == board[8] && board[8] != 0)
	       {
	           return true;
	       }
	       else if(board[0] == board[3] && board[3] == board[6] && board[6] != 0)
	       {
	           return true;
	       }
	       else if(board[1] == board[4] && board[4] == board[7] && board[7] != 0)
	       {
	           return true;
	       }
	       else if(board[2] == board[5] && board[5] == board[8] && board[8] != 0)
	       {
	           return true;
	       }
	       else if(board[0] == board[4] && board[4] == board[8] && board[8] != 0)
	       {
	           return true;
	       }
	       else if(board[2] == board[4] && board[4] == board[6] && board[6] != 0)
	       {
	           return true;
	       }
	       else return false;
     }
	   public void Display(){
	       for(int i = 0; i <=8; i++){
	           if(i % 3 == 0 && i > 0) System.out.println();
	           System.out.print(board[i] + " ");
	       }
	       System.out.println();
	   }
}
