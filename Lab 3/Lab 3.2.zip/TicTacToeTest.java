import java.util.Scanner;
public class TicTacToeTest {
	public static void main(String args[])
	{
	       TicTacToe game = new TicTacToe();
	       Scanner enter = new Scanner(System.in);
	       while(true)
	       {
	    	   game.Display();
	           System.out.print("Player " + game.turn + "'s turn. Enter the position(0-8): ");
	           int position = enter.nextInt();
	           game.move(game.turn, position);
	           if(game.won() || game.tie())
	           {
	        	   game.Display();
	        	   game.win();
	               break;
	           }
	       }
	  }
}
