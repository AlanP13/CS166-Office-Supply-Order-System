import java.util.Scanner;
public class EncryptionTest
{
  public static void main(String[] args) 
  {
		System.out.println("Enter the sentence you want to encrypt");
		Scanner scan = new Scanner(System.in);
		String string = scan.nextLine();
		Encryption test = new Encryption(string);
		String encrypt = test.getEncryptWord();
		String decrypt = test.Decrypt(encrypt);
		System.out.println("Encrypted :" + encrypt +"\n" + "Decrypted :" + decrypt);
		 
  }
}
