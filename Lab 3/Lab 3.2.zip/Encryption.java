import java.util.Random;
public class Encryption 
{
	Random ran = new Random();
	private String[] alphabet = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
	private int[] rand = new int[26];
	private String[] encryptAlph = new String[26];
	private String[] word;
	private String encrypt = "";
	private String decrypt = "";
	public Encryption(String word1)
	{
		for(int i = 0; i < rand.length; i++)
		{
			rand[i] = i;
		}
		
			for(int i = 0; i < rand.length; i++)
			{
				int randomTest = (int)Math.floor(Math.random() * (i+1));
				int temp = rand[i];
				rand[i] = rand[randomTest];
				rand[randomTest] = temp;
			}
			
		for(int i = 0; i < rand.length; i++)
		{
			encryptAlph[i] = alphabet[rand[i]] ;
		}
		
		word= new String[word1.length()];
		
		System.out.println(encrypt);
		for(int i = 0; i < word.length; i++)
		{
			word[i] = word1.substring(i,i+1);
			
		}
		
		for(int i = 0; i < word.length; i++)
		{
			for(int k = 0; k < alphabet.length; k++)
			{
				if(alphabet[k].equalsIgnoreCase(word[i]))
				{
					
					encrypt = encrypt + encryptAlph[k];
				}
			}
			if(word[i].equals(" "))
			{
				encrypt = encrypt + " ";	
			}
		}
		}
	public String getEncryptWord()
	{
		return encrypt;
	}	
	public String Decrypt(String word1)
	{
		word = new String[word1.length()];
		for(int i = 0; i < word.length; i++)
		{
			word[i] = word1.substring(i,i+1);
			
		}
		for(int i = 0; i < word.length; i++)
		{
			for(int k = 0; k < encryptAlph.length; k++)
			{
				if(encryptAlph[k].equalsIgnoreCase(word[i]))
				{
					
					decrypt = decrypt + alphabet[k];
				}
			}
			if(word[i].equals(" "))
			{
				decrypt= decrypt + " ";	
			}
		}
		return decrypt;
		}

	}
		
	


	

