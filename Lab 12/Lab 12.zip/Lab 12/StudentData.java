public class StudentData 
{
	private static String first ;
	private static String last ;
	private static String email ;
	private static String department ;
	private static double gpa ;
	private static int year ;
	private static char semester ;
	
	public  StudentData ( String first1 , String last1 , String email1 , String department1 , double gpa1 , int year1 , char semester1 ) 
			{
	first=first1;
	last=last1;
	email=email1;
	department=department1;
	gpa=gpa1;
	year=year1;
	semester=semester1;
			}
	
	public void Display()
	 {
		System.out.print("First Name: "+first+"\n"+"Last Name: "+last+"\n"+"Email: "+email+"\n"+"Department: "+department+"\n"+"GPA: "+gpa+"\n"+"Year: "+year+"\n"+"Semester: "+semester+"\n");
		 
	 }
}

