import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
public class Student
{
	private static String first ;
	private static String last ;
	private static String email ;
	private static String department ;
	private static double gpa ;
	private static int year ;
	private static char semester ;
	public static void main(String[] args) 
	{
	 JFrame frame = new JFrame("Student");
     frame.setLayout(new GridLayout(3, 1));
     frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     frame.setPreferredSize(new Dimension(350, 400));
     JPanel First = new JPanel();
     JPanel Second = new JPanel();
     JPanel Third = new JPanel();
     JLabel first1 = new JLabel("First Name: ");
     JTextField first1Area = new JTextField(20);
     JLabel last1 = new JLabel("Last Name: ");
     JTextField last1Area = new JTextField(20);
     JLabel email1 = new JLabel("Student email: ");
     JTextField email1Area = new JTextField(20);
     JLabel department1 = new JLabel("Department: ");
     JTextField department1Area = new JTextField(20);
     First.add(first1);
     First.add(first1Area);
     First.add(last1);
     First.add(last1Area);
     First.add(email1);
     First.add(email1Area);
     First.add(department1);
     First.add(department1Area);
     JLabel gpa1 = new JLabel("GPA: ");
     JTextField gpa1Area = new JTextField(10);
     JLabel year1 = new JLabel("Year: ");
     JTextField year1Area = new JTextField(10);
     JCheckBox Fall = new JCheckBox("Fall");
     JCheckBox Spring = new JCheckBox("Spring");
     Second.add(gpa1);
     Second.add(gpa1Area);
     Second.add(year1);
     Second.add(year1Area);
     Second.add(Fall);
     Second.add(Spring);
     JButton New = new JButton("New");
     JButton Save = new JButton("Save");
     JButton Exit = new JButton("Exit");
     Save.addActionListener(new ActionListener() 
     {
         @Override
         public void actionPerformed(ActionEvent e) 
         {
        	 if(Fall.isSelected()) {
            	 semester='F';
             }
             if(Spring.isSelected()) {
                 semester='S';
             }
             first=first1Area.getText();
             last= last1Area.getText();
             email=email1Area.getText();
             department=department1Area.getText();
             gpa=Double.parseDouble(gpa1Area.getText());
             year=Integer.parseInt(year1Area.getText());
			                 StudentData emailArea1=new StudentData( first,last,email,department,gpa,year,semester);
			                 emailArea1.Display();
         }
     });
    
     New.addActionListener(new ActionListener() 
     {
         @Override
         public void actionPerformed(ActionEvent e) 
         {
             first1Area.setText(null);
             last1Area.setText(null);
             email1Area.setText(null);
             department1Area.setText(null);
             gpa1Area.setText(null);
             year1Area.setText(null);
             Fall.setSelected(false);
             Spring.setSelected(false);
            }
     });
    Exit.addActionListener(new ActionListener() 
     {
         @Override
         public void actionPerformed(ActionEvent e) {
             int option = JOptionPane.showConfirmDialog(frame, "Are you sure?");
             if(option == JOptionPane.YES_OPTION) {
                 frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
             }
         }
     });
     Third.add(New);
     Third.add(Save);
     Third.add(Exit);
     frame.add(First);
     frame.add(Second);
     frame.add(Third);
     frame.pack();
     frame.setVisible(true);
 }
}

