import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;  
public class Counter
{
	 private static JLabel counterLabel;    
	   private static TextField counterField; 
	   private static Button counterButton;   
	private static int count = 0;
	public static void main(String[] args) 
	{
		JFrame frame = new JFrame("Counter");
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    counterField = new TextField(count + "", 10);
	    counterField.setEditable(false);   
	    counterButton= new Button("Count");
	    JPanel First = new JPanel();
	    counterLabel = new JLabel("Counter: ");
	    First.add(counterLabel);
	    First.add(counterField);
	    First.add(counterButton);
	    counterButton.addActionListener(new ActionListener() {
	           @Override
	           public void actionPerformed(ActionEvent e) {
	        	   ++count;                
	        	   counterField.setText(count + "");
	           }
	       });
	    frame.add(First);
	    frame.pack();
	    frame.setVisible(true);
    }
}
