package com.labs.lab6;
public class CircleClient {
public static void main(String[] args) {
int radius = 10;
int length = 20;
Cylinder cy = new Cylinder(radius, length);
System.out.println("Area of circle with radius " + radius + " is " + cy.getAreaCircle());
System.out.println("Perimeter of circle with radius " + radius + " is " + cy.getPerimeterCircle());
System.out.println("Area of Cylinder with radius " + radius + " is " + cy.getAreaCylinder());
System.out.println("Volume of Cylinder with radius " + radius + " is " + cy.getVolumeCylinder());
}
}

