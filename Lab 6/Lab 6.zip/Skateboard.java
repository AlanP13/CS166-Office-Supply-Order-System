package com.labs.lab6;
public class Skateboard extends Vehicle {
    private double myBoardLength;
    public Skateboard(){
        myBoardLength = 1;
    }
    public Skateboard(double boardLength){
        setBoardLength(boardLength);
    }
    public double getBoardLength(){
        return myBoardLength;
    }
    public void setBoardLength(double d) {
        myBoardLength = d;
    }
}