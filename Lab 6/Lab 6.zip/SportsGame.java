package com.labs.lab6;
public class SportsGame extends Game 
{
	int players=0;
	boolean Tie;
	public String gameType=" ";
public SportsGame(String newDescription,int players1,boolean Tie1)
{
	super(newDescription);
	players=players1;
	Tie=Tie1;
	if (players > 2)
    {
    	gameType= "Team";
    }    
    else 
    {
        if (players ==2)
        {
        	gameType=  "Individual";
        }
        else
        {
        	gameType= "N/A";
        }
    }
}
public String toString()
{
return " 1. Number of Players: " + players + " 2.Game Type: " + gameType
+ " 3. Can the game tie: " + Tie;
}
}