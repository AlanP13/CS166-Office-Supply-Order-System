package com.labs.lab6;
public class Cylinder extends Circle {
private int length;
public Cylinder(double r, int length) {
super(r);
this.length = length;
}
public int getLength() {
return length;
}
public void setLength(int length) {
this.length = length;
}
public double getVolumeCylinder() {
return 4 / 3 * Math.PI * getRadius() * getRadius() * getRadius();
}
public double getAreaCylinder() {
return 4 * Math.PI * getRadius() * getRadius();
}
}

