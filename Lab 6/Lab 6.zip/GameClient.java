package com.labs.lab6;
public class GameClient {
	 public static void main(String[] args) {
		 PCGame pcGame = new PCGame("Minecraft",5,160,1.5);
	     System.out.println("Game name is " + pcGame.getDescription());
	     System.out.println(pcGame);  
		 BoardGame boardGame = new BoardGame("Snake and Ladder", 3, 10, false);
		 System.out.println("Game name is " + boardGame.getDescription());   
		 System.out.println(boardGame);
		 SportsGame sportGame=new SportsGame("Baseball",18,false);
		 System.out.println("Game name is " + sportGame.getDescription());   
		 System.out.println(sportGame);
		 
		 }
}