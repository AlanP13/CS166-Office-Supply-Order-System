package com.labs.lab6;
public class PCGame extends Game {

   private int minram;
   private int mbhdd;
   private double mincpu;
   public PCGame(String desc,int mr,int md,double per)
   {
   super(desc);
   setmb_for_ram(mr);
   setmb_needed_for_hd(md);
   setmin_GHZ_performance_cpu(per);
   }
   public void setmb_for_ram(int r)
   {
	   minram = r;
   }
   public void setmb_needed_for_hd(int r)
   {
	   mbhdd = r;
   }
   public void setmin_GHZ_performance_cpu(double r)
   {
	   mincpu = r;
   }
   public int getmin_mb_for_ram()
   {
   return minram;
   }
   public int getmb_needed_for_hd()
   {
   return mbhdd;
   }
   public double getmin_GHZ_performance_cpu()
   {
   return mincpu;
   }
   public String toString()
   {
   return " 1. Minimum ram in (MB) " + minram + " 2. Hard drived required (MB) " + mbhdd
   + " 3. minimum CPU " + mincpu;
   }  
}