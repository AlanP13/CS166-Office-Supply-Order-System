package com.labs.lab6;
public class BoardGame extends Game {

    private int minPlayers, maxPlayers;
    private boolean Tie;

    public BoardGame(String newDescription, int minPlayers, int maxPlayers, boolean Tie) {
        super(newDescription);
        this.minPlayers = minPlayers;
        this.maxPlayers = maxPlayers;
        this.Tie = Tie;
    }

    public String toString() {
    	return " 1. Minimum Players: " + minPlayers +
                " 2. Maximum Players: " + maxPlayers +
                " 3. Can the game tie: " + Tie;
    }
}