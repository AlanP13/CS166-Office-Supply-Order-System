import java.util.Scanner;
public class Problem3
{
	public static void main(String[] args)  
	{ 
		String sentence;
		System.out.println("Enter the sentence you want to capitalize.");
		Scanner input = new Scanner(System.in);
		sentence=input.nextLine();
		printCapitalized(sentence);
	}
	static void printCapitalized( String str )
	{
		char character;
		char previous;
		int i;
		previous='.';
		for ( i = 0;  i < str.length();  i++ ) {
			character = str.charAt(i);
	        if ( Character.isLetter(character)  &&  ! Character.isLetter(previous) )
	           System.out.print( Character.toUpperCase(character) );
	        else
	           System.out.print( character );
	        previous=character;
		}
	    System.out.println();
	 }
}
