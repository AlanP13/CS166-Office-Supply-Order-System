
public class Problem6 {

	public static void main(String[] args) {
		Counter c1=new Counter();
		int number=0;
		int n=10;//The number of times the counter should be increment
		for(int i=0;i<=n-1;i++)
		{
			c1.increment();
		}
		number=c1.getVale();
		System.out.println(number);
	}

}
