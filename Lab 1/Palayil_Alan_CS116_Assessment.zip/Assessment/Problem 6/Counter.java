public class Counter 
{
private int counter;
 Counter()
 {
	 counter=0;
 }
 public int getVale()
 {
	 return counter;
 }
 public void setValue(int count)
 {
	 counter=count;
 }
 public void increment()
 {
	 counter++;
 }
}
