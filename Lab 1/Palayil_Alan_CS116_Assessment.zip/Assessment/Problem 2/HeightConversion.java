
public class HeightConversion {
double feet;
double inch;
double height;
HeightConversion()
{
	feet=0;
	inch=0;
}
public String getHeight(double feet1, double inch1)
{
	feet=feet1*30.48;
	inch= inch1*2.54;
	height=feet+inch;
	return "The Height is:"+height+"cm";
}
public String getHeight(double cm)
{
	double inch = 0.3937 * cm; 
    double feet = 0.0328 * cm;
    return "The Height is:"+feet+"ft or "+inch+"in";
}
}
