import java.util.Scanner;
public class Problem2 
{
	public static void main(String[] args) 
	{
		System.out.println("Type 1 to enter your height in feet and inches");
		System.out.println("Type 2 to enter your height in centimeters");
		System.out.println("Type 0 to exit");
		Scanner enter = new Scanner(System.in);
	    String input =enter.nextLine();
	    int ans=Integer.parseInt(input);
		if(ans==1)
		{
			double feet;
			double inch;
			String height;
			HeightConversion Height1=new HeightConversion();
			System.out.println("Enter the height in feet");
			Scanner FeetReader = new Scanner(System.in);
			String feeti= FeetReader.nextLine(); 
			feet=Double.parseDouble(feeti);
			System.out.println("Enter the height in feet");
			Scanner InchReader = new Scanner(System.in);
			String inchi= InchReader.nextLine(); 
			inch=Double.parseDouble(inchi);
			if(feet>0.0 && inch>=0.0)
			{
				height=Height1.getHeight(feet,inch);
				System.out.println(height);
			}
			else
			{
				System.err.println("You have entered invalid data!");
			}
		}
		else if(ans==2)
		{
			double cm;
			String height;
			HeightConversion Height1=new HeightConversion();
			System.out.println("Enter the height in centimeters");
			Scanner cmReader = new Scanner(System.in);
			String cmi= cmReader.nextLine(); 
			cm=Double.parseDouble(cmi);
			if(cm>0.0)
			{
				height=Height1.getHeight(cm);
				System.out.println(height);
			}
			else
			{
				System.err.println("You have entered invalid data!");
			}
			
			
		}
		else
		{
			System.out.println("Program end. Good Bye");
		}
	}
}
