import java.util.*;  
public class Grades {
private int[] grade;
private int high,mode;
private double aver,median;
public Grades(int n)
{   
	Random r=new Random();
    grade = new int[n];
  
    for(int i = 0;i<n; i++)
    {
    	grade[i] = Math.abs(r.nextInt())%101;
    }
}
public double getTotal()
{
    int total = 0;
    for(int i=0;i<grade.length;i++)
    {
    	total+=grade[i];
    }               
    return total;
}
public void AverageCal()
{           
	aver= getTotal() / (double)grade.length;
}
public int getHigh()
{
	return high;
}
public double getMedian()
{
	return median;
}
public int getMode()
{
	return mode;
}
public double getAverage()
{
	return aver;
}
public void highest()
{   
    	high = grade[grade.length-1];
}
public void sort()
{ 
	int t;
    for(int i=0;i<grade.length-1;i++)
    {
      for(int j=i+1;j<grade.length;j++)
    	{
          if(grade[i]>grade[j])
              {
        	    t=grade[i];
                grade[i]=grade[j];
                grade[j]=t;
              }
    	}
     }          
}   
public void MedianCal()
{
	if(grade.length%2==0)
	{
		median=(grade[grade.length/2-1]+grade[(grade.length)/2])/2.;
	}
else
      {
	   median=grade[grade.length/2];
      }
}
public void ModeCal()
{
	int []a=new int[101];
    int i,m;
for(i=0;i<=grade.length;i++)
	a[i]=0;
for(i=0;i<grade.length;i++)
	a[grade[i]]++;
    m=0;
for(i=0;i<a.length;i++)
     if(a[i]>a[m])
          m=i;
mode=m;
}
public String toString()
{int i;
String s="";
for(i=0;i<grade.length;i++)
{s=s+grade[i]+" ";
if((i+1)%10==0)
     s=s+'\n';
   
}
return s;
}
}