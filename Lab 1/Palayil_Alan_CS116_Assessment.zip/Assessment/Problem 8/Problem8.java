import java.util.Scanner;
public class Problem8 
{
	public static void main(String[] args) 
	{
		Scanner input=new Scanner(System.in);
		int no;
	    System.out.print("How many students are there: ");
	    no=input.nextInt();
	    Grades g=new Grades(no);
	    g.Sorting();
	    g.Highest();
	    g.AverageCal();
	    g.MedianCal();
	    g.ModeCal();
	    System.out.println("The sorted array is:\n"+g.toString());
	    System.out.println("Highest grade: "+g.getHigh());
	    System.out.println("Average grade: "+g.getAverage());
	    System.out.println("Median grade: "+g.getMedian());
	    System.out.println("Mode: "+g.getMode());
	}

}
