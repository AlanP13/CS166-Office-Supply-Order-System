public class Problem7 {

	public static void main(String[] args) 
	{
		Counter headCount  = new Counter();
		Counter tailCount=new Counter();
		int heads,tails;		
		for ( int flip = 0; flip < 100; flip++ ) 
		{ 
			if (Math.random() < 0.5)
			{
				headCount.increment();
			}
			else
			{
				tailCount.increment();
			}
		}
		heads=headCount.getVale();
		tails=tailCount.getVale();
		System.out.println("There were " +heads + " heads.");
		System.out.println("There were " + tails + " tails.");
	}

}
