import java.lang.Object;
import java.text.DecimalFormat;
public class Problem5 {
	public static void main(String[] args) 
	  {  
		  Die die1 = new Die(); 
		  Die die2 = new Die(); 
		  int counter2=0;
		  int counter3=0;
		  int counter4=0;
		  int counter5=0;
		  int counter6=0;
		  int counter7=0;
		  int counter8=0;
		  int counter9=0;
		  int counter10=0;
		  int counter11=0;
		  int counter12=0;
		  int total_time=10000;
		  for(int i=0;i<total_time;i++)
	      {
			  die1.roll(); die2.roll(); 
			  int side1=die1.getSide(); 
			  int side2=die2.getSide(); 
			  int target = side1+side2; 
			  int sum=target;
			  switch(sum) {
			  case 1:
				  System.err.println("Impossible roll");
				  break;
		      case 2:
		    	  counter2++;
		    	  break;
		      case 3:
		    	  counter3++;
		    	  break;
		      case 4:
		    	  counter4++;
		    	  break;
		      case 5:
		    	  counter5++;
		    	  break;
		      case 6:
		    	  counter6++;
		    	  break;
		      case 7:
		    	  counter7++;
		    	  break;
		      case 8:
		    	  counter8++;
		    	  break;
			  case 9:
				  counter9++;
		    	  break;
		      case 10:
		    	  counter10++;
		    	  break;
		      case 11:
		    	  counter11++;
		    	  break;
		      case 12:
		    	  counter12++;
		    	  break;
			  default:System.err.println("Impossible roll");
			  break;
			  }
         }
		  DecimalFormat df = new DecimalFormat("###.######");
		 int two=counter2;
		 double aver=two*100/total_time;
		  System.out.println("Total on Dice| Average");
		  System.out.println(" 2           |  "+counter2*100/total_time);
		  System.out.println(" 3           |  "+counter3*100/total_time);
		  System.out.println(" 4           |  "+counter4*100/total_time);
		  System.out.println(" 5           |  "+counter5*100/total_time);
		  System.out.println(" 6           |  "+counter6*100/total_time);
		  System.out.println(" 7           |  "+counter7*100/total_time);
		  System.out.println(" 8           |  "+counter8*100/total_time);
		  System.out.println(" 9           |  "+counter9*100/total_time);
		  System.out.println("10           |  "+counter10*100/total_time);
		  System.out.println("11           |  "+counter11*100/total_time);
		  System.out.println("12           |  "+counter12*100/total_time);
}
}