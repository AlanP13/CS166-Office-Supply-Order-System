public class Problem4
{
  public static void main(String[] args) 
  {  
     Die die1 = new Die(); 
     Die die2 = new Die(); 
     die1.roll(); die2.roll(); 
     int side1=die1.getSide(); 
     int side2=die2.getSide(); 
	 int target = side1+side2; 
	 int current=0;
	 int counter =0;
	 if(target<=12&&target>=1)
	 {
	  System.out.println("You rolled: " + side1 + 
	   " + " + side2 + " = " + target ); 
      counter++;	   
	  if (target==2) 
	   {
		  System.out.println("You've rolled snake eyes"); 
		  System.out.println("Number of rolls for snake eyes: "+counter);
	   }
	  else 
	  { 
	   while (current!=2) 
	   { 
	    die1.roll(); die2.roll(); 
	    side1=die1.getSide(); 
	    side2=die2.getSide(); 
	    current = side1+side2; 
	    System.out.println("You rolled: " + side1 + 
	      " + " + side2 + " = " + current); 
	    counter++;
	   } 
	    System.out.println("You've rolled snake eyes");
	    System.out.println("Number of rolls for snake eyes: "+counter);
	  }
	 }
	  else
		  System.err.println("Impossible Play");
  }
}