
public class HeightConversion {
double feet;
double inch;
HeightConversion()
{
	feet=0;
	inch=0;
}
public double getHeight(double feet1, double inch1)
{
	feet=feet1*30.48;
	inch= inch1*2.54;
	return feet+inch;
}
}
