import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
public class ArrayListStringTest 
{
   public static void main(String[] args) 
   {
       ArrayList<String> list = new ArrayList<String>();
       list.add("apple");
       list.add("boys");
       list.add("cats");
       list.add("zoo");
   	Integer[] list1={1, 4, 8, 9, 11, 15, 17, 28, 41, 59};
   	Integer[] list2={4, 7, 11, 17, 19, 20, 23, 28, 37, 59, 81};
       ArrayListString a=new ArrayListString();
       a.getStringElements(list);
       a.getListsElements(list1,list2);
       System.out.println("Reversed list : "+a.reverese(list));
       System.out.println("Capitalized Plurals list: "+a.capitalizedPlurals(list));
       a.removePlurals(list);
       a.FinalLists();
   }
}