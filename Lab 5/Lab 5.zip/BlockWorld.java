import java.io.*; 
import java.util.*; 
public class BlockWorld {
	int n;  
	boolean[][] blockworld;       
	public BlockWorld() {           
		this.blockworld=new boolean[10][10];
		this.n=10;     
		for(int i=0;i<n;i++)    
			for(int j=0;j<n;j++)   
				blockworld[i][j]=false;                         
		} 
	public BlockWorld(int n) 
	{              
		this.n = n;
		this.blockworld=new boolean[n][n];
		for(int i=0;i<n;i++) 
			for(int j=0;j<n;j++) 
				blockworld[i][j]=false;        
		}      
	public boolean getColor(int x,int y)   
	{  
		return blockworld[x][y]; 
		}      
	public void setCellColor(int x,int y,boolean setWhite)  
	{             
		blockworld[x][y]=setWhite;
		}           
	public String toString() 
	{      
		StringBuffer buf=new StringBuffer();      
		for(int i=0;i<n;i++) 
		{
			for(int j=0;j<n;j++)
			{                  
				if(blockworld[i][j])    
					buf.append(" "); 
				else   
					buf.append("X");  
				}                    
			buf.append("\n"); 
			}            
		return buf.toString();  
		}   
	public static void main(String[] args)  {
		Scanner sc=new Scanner(System.in);     
		System.out.println("Enter BlockWorld size");   
		int size=sc.nextInt();    
		BlockWorld n=new BlockWorld(size);
n.setCellColor(0, 0,true);
n.setCellColor(2, 2,true);
System.out.println(n.toString());
} 
} 
