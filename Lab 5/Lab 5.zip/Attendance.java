import java.util.Random;
public class Attendance {

   public static void main(String[] args) {
      
       Random r = new Random();
       int[][] attendance = new int[4][5];
       for(int i = 0 ; i < 4 ; i++) {
           for(int j = 0 ; j < 5 ; j++) {
               attendance[i][j] = r.nextInt(11) + 40 ;
           }
       }
       System.out.println("\t Day1 Day2 Day3 Day4 Day5");
       for(int i = 0 ; i < 4 ; i++) {
           System.out.printf("Week%d\t ",(i+1));
           for(int j = 0 ; j < 5 ; j++) {
               System.out.printf(" %d ", attendance[i][j]);
               System.out.printf(" ");
           }
           System.out.println("");
       }
       System.out.println("Average attendance of every week are as below:");
       int sum ;
       for(int i = 0 ; i < 4 ; i++) {
           sum = 0 ;
           for(int j = 0 ; j < 5 ; j++) {
               sum += attendance[i][j];
           }
           System.out.printf("WEEK%d : %.2f\n",(i+1), (sum / 5.0));
       }

   }

}