public class TestComputerKit {

	   public static void main(String[] args) {
	      
	       ComputerKit kit = new ComputerKit();
	       kit.add(new ComputerPart("cpu", 360));
	       kit.add(new ComputerPart("memory", 180));
	       kit.add(new ComputerPart("memory", 180));
	       kit.add(new ComputerPart("memory", 180));
	       kit.add(new ComputerPart("memory", 180));
	       kit.add(new ComputerPart("camera", 720));
	       System.out.println("Cost type of computer kit is : " + kit.costType());
	       System.out.println("Number of cpu items in the kit : " + kit.numOfItemType("cpu"));
	       System.out.println("Number of camera items in the kit : " + kit.numOfItemType("camera"));
	       System.out.println("Number of memory items in the kit : " + kit.numOfItemType("memory"));
	   }

	}