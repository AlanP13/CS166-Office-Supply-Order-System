import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
public class ArrayListString 
{
	ArrayList<String> list = new ArrayList<String>();
	static Integer[] list1;
	static Integer[] list2;
	public void getStringElements(ArrayList<String> list1)
	{
		list=list1;
	}
	public void getListsElements(Integer[] lista,Integer[] listb)
	{
		list1=lista;
		list2=listb;
	}
	   public static ArrayList<String> reverese(ArrayList<String> list){
	       for(int i=0; i<list.size()/2;i++){
	           String s = list.get(i);
	           list.set(i, list.get(list.size()-1-i));
	           list.set(list.size()-1-i, s);
	       }
	      
	       return list;
	   }
	   public static ArrayList<String> capitalizedPlurals(ArrayList<String> list){
	       for(int i=0; i<list.size(); i++){
	           if(list.get(i).endsWith("s")){
	               list.set(i, list.get(i).toUpperCase());
	           }
	       }
	       return list;
	   }
	   public static void removePlurals(ArrayList<String> list)
	   {
	       for(int i=0; i<list.size(); i++)
	       {
	           if(list.get(i).endsWith("s") || list.get(i).endsWith("S"))
	           {
	               list.remove(i);
	                i--;
	           }
	       }
	           System.out.println("Remove Plurals list: "+list);
	    }
	   public static void FinalLists()
	   {	List<Integer> aList1=Arrays.asList(list1);
			List<Integer> aList2=Arrays.asList(list2);
			List<Integer> fList=Intersect(aList1,aList2);
			sortArray(fList);
			PrintArray(fList);
       }
		public static List<Integer> Intersect(List<Integer> a1,List<Integer> a2)
		{
			List<Integer> fList=new ArrayList<Integer>();
			for(Integer t:a1)
			{
				for(Integer t2:a2)
				{
					if(t.equals(t2))
					{
						if(!isFound(fList,t))
								fList.add(t);
					}
				}
			}
			return fList;
		}
		public static void PrintArray(List<Integer> aList)
		{
			System.out.print("Final Array are: [");
			for(Integer f:aList)
			{
				System.out.print(f+" ");
			}
			System.out.print("]");
		}
		public static boolean isFound(List<Integer> aList, Integer data)
		{
			boolean found=false;
			for(Integer t:aList)
			{
				if(t.equals(data))
				{
					found=true;
					return found;
				}
			}
			return found;
		}
		public static void sortArray(List<Integer> aList)
		{
			int i,j,t;
			for(i=0;i<aList.size()-1;i++)
			{
				for(j=i+1;j<aList.size();j++)
				{
					if(aList.get(i)>=aList.get(j))
					{
						t=aList.get(i);
						aList.set(i,aList.get(j));
						aList.set(j,t);
					}
				}
			}
}
}
