import java.util.Scanner;

public class MatrixManipulationDriver {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int [] [] MatrixA = new int [2][3];
		int [] [] MatrixB = new int [3][2];
		int [] [] MatrixP = new int [2][2];
		System.out.println("Please Enter the Values of Matrix A [2 X 3]");
		for(int i = 0; i < MatrixA.length; i++)
		{
			for(int j = 0; j < MatrixA[0].length; j++)
			{
				MatrixA [i][j] = scan.nextInt();
			}
		}
		System.out.println("Please Enter the Values of Matrix B [3 X 2]");
		for(int i = 0; i < MatrixB.length; i++)
		{
			for(int j = 0; j < MatrixB[0].length; j++)
			{
				MatrixB [i][j] = scan.nextInt();
			}
		}
	
		MatrixManipulation matrix = new MatrixManipulation(MatrixA, MatrixB);
		
		MatrixA = matrix.getMatrixA();
		System.out.println("Matrix A ");
		for(int i = 0; i < MatrixA.length; i++)
		{
			for(int j = 0; j < MatrixA[0].length; j++)
			{
				System.out.print(MatrixA[i][j] + " ");
			}
			System.out.println(" ");
		}
		
		MatrixB = matrix.getMatrixB();
		System.out.println("Matrix B ");
		for(int i = 0; i < MatrixB.length; i++)
		{
			for(int j = 0; j < MatrixB[0].length; j++)
			{
				System.out.print(MatrixB[i][j] + " ");
			}
			System.out.println(" ");
		}
		
		MatrixP = matrix.getMatrixP();
		System.out.println("Product of A and B is ");
		for(int i = 0; i < MatrixP.length; i++)
		{
			for(int j = 0; j < MatrixP[0].length; j++)
			{
				System.out.print(MatrixP[i][j] + " ");
			}
			System.out.println(" ");
		}
		
	}

}
