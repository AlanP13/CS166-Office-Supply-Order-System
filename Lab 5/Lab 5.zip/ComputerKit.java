import java.util.*;
public class ComputerKit {
	   ArrayList<ComputerPart> computerParts ;

	   public ComputerKit() {
	       computerParts = new ArrayList<ComputerPart>();
	   }
	   public void add(ComputerPart part) {
	       computerParts.add(part);
	   }
	   public String costType() {
	       double total = 0 ;
	       for(ComputerPart part : computerParts)
	           total += part.price ;
	       if(total > 1000)
	           return "expensive" ;
	       else if(total > 250)
	           return "normal" ;
	       else
	           return "cheap" ;
	   }
	   public int numOfItemType(String itemType) {
	       int count = 0 ;
	       for(ComputerPart part : computerParts) {
	           if(part.item.contentEquals(itemType))
	               count+= 1 ;
	       }
	       return count ;
	   }
	  
	}
