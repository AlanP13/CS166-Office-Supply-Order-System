public class MatrixManipulation {
	int [] [] MatA = new int [2][3];
	int [] [] MatB = new int [3][2];
	int [] [] Product = new int [2][2];
	int count = 0;
	public MatrixManipulation(int [] [] Matrix1, int [] [] Matrix2)
	{
		MatA = Matrix1;
		MatB = Matrix2;
		for(int i = 0; i < Product.length; i++)
			{
				for(int j = 0; j < Product[0].length; j++)
				{
					Product[i][j] = 0;
				}
			}
			count = 0;
			for(int j = 0; j < MatA[0].length; j++)
			{
				count = count + (MatA[0][j] * MatB[j][0]);
			}
			Product[0][0] = count;
			count = 0;
			for(int j = 0; j < MatA[0].length; j++)
			{
				count = count + (MatA[0][j] * MatB[j][1]);
			}
			Product[0][1] = count;
			count = 0;
			for(int j = 0; j < MatA[0].length; j++)
			{
				count = count + (MatA[1][j] * MatB[j][0]);
			}
			Product[1][0] = count;
			count = 0;
			for(int j = 0; j < MatA[0].length; j++)
			{
				count = count + (MatA[1][j] * MatB[j][1]);
			}
			Product[1][1] = count;
	}
	public int [][] getMatrixA()
	{
		return this.MatA;
	}
	public int [][] getMatrixB()
	{
		return this.MatB;
	}
	public int [][] getMatrixP()
	{
		return this.Product;
	}
}
