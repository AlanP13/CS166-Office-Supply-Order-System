public class ComputerPart
{
   String item ;
   double price ;
   public ComputerPart(String item, double price) 
   {
       this.item = item;
       this.price = price;
   }
   
  
}