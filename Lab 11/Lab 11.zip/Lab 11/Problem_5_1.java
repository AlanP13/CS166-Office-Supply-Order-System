public class Problem_5_1 {
	public static void main(String[] args) 
	{
		 int[] A = {10, 15, 1, 2, 33, 48};
	        System.out.println(search(A, A.length, 11));
	        System.out.println();
	        System.out.println(Fib(7));
	        System.out.println();
	        printNoOfTimes("Stay Home, Stay Safe!", 2);
	        System.out.println();
	        System.out.println(power(2, 9));
	}
	//Problem 5.1
    private static boolean search(int[] A, int size, int n) {

        if (size == 0) return A[0] == n;
        else if (A[size - 1] == n) return true;
        else return search(A, size - 1, n);

    }
    //Problem 5.2
	private static int Fib(int n) {
        if (n == 1) return 1;
        else if (n == 2) return 1;
        else return Fib(n - 1) + Fib(n - 2);
    }
	//Problem 5.3
	public static void printNoOfTimes(String s, int i) {
        if (i == 0) {
            System.out.println(s);
        } else {
            printNoOfTimes(s, i - 1);
            printNoOfTimes(s, i - 1);
        }
    }
	//Problem 5.4
    public static double power(double x, int y) {
        if (y == 0) {
            return 1;
        } else {
            return x * power(x, y - 1);
        }
    }
}
