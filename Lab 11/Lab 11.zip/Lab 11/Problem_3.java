import java.util.Scanner;
public class Problem_3 
{
	public static int foo(String s,char c)
	{
	if (s.length() ==0)
	{
		   return 0;	
	}
	else
	{
		int count=0;
		for(int i=0;i<s.length();i++)
		{
			if(s.charAt(i) == c){  
				count++;
			}
		}
		return count;
	}
	}
	public static void main(String[] args) 
	{
		Scanner input= new Scanner(System.in);
		System.out.println("Enter the String:");
		String s= input.nextLine();
		s=s.toUpperCase();
		System.out.println("Enter the String:");
		String sc= input.next();
		char c = sc.charAt(0);
		c=Character.toUpperCase(c);
		System.out.println(foo(s,c));
	}
}
/*
Enter the String:
I am the one who knows the Omega and Alpha, end and the founder of genesis.
Enter the String:
a
6

*/
