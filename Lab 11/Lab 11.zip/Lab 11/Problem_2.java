import java.util.Scanner;

public class Problem_2 
{
public static int fool(int n)
{
	if(n==0)
	{
		return 0;
	}
	else if(n>0)
	{
		return fool(n-1);
	}
	else
	{
		return fool(n+1);
	}
}
public static void main(String[] args) 
{
	int i=fool(0);
	System.out.println(i);
	i=fool(4);
	System.out.println(i);
}
}
