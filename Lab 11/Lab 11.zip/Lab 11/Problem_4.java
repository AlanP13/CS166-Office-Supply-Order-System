public class Problem_4 
{
	static int factorial (int n) {
		if (n <= 1)
		return 1;
		else
		return (n * factorial (n -1));
		}
	static int add ( int i, int j) { 
		if (i == 0)
		return j;
		else
		return add (i -1, j +1);
		}
	public static void main(String[] args) 
	{
		int factorial,add;
		factorial=factorial(6);
		add=add(5,9);
		System.out.println(factorial);
		System.out.println(add);
	}
}
