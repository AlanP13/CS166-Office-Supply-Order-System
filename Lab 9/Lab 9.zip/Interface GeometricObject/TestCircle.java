public class TestCircle {

    public static void main(String[] args) {

        	GeometricObject test1 = new Circle(100);
		System.out.println("Perimiter = " + test1.getPerimeter());
		System.out.println("Area = " + test1.getArea());
        }

    }
}