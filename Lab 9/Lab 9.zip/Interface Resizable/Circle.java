public abstract class Circle
{
  protected double radius;
public Circle( double radius)
{
this.radius = radius;
}
}
