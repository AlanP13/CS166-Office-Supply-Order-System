import java.util.*;
class TestResizableCircle 
{
public static void main(String[] args) 
{
	Scanner scan = new Scanner(System.in);
	double input;
	System.out.print("Enter the Radius: ");
	input = scan.nextDouble();
	ResizableCircle rc = new ResizableCircle(input);
System.out.println("Result of method resize is " +rc.resize(2));
}
}